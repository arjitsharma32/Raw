﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuessTime
{
    public partial class Form1 : Form
    {
        int waitTime;
        DateTime start, end;
        Button BTemp;
        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("Welcome to the time game", "Instructions");
            MessageBox.Show("Lets check your time guessing power Muhahahahaha", "Instructions");
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Random rnd = new Random();
            waitTime = rnd.Next(5, 20);
            start = DateTime.Now;
            String s = waitTime.ToString();
            textBox1.Text = s;
           }
        
        private void button2_Click(object sender, EventArgs e)
        {
            end = DateTime.Now;
            float playerWaitTime = end.Second - start.Second;
            float error = Math.Abs(waitTime - playerWaitTime);
           textBox2.Text= playerWaitTime.ToString();
            if(error == 0)
            {
                MessageBox.Show("Broooooo..... U won");
            }
            else
            { 
            MessageBox.Show(" Missed by " + error + " seconds");
            }
        }
    }
}
